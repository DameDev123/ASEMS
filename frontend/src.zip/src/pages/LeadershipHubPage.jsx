import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Tabs from '../components/Tabs.jsx';
import { EmptyBlock } from '../components/StateBlocks.jsx';
import OfficesPage from './OfficesPage.jsx';
import ReferralsPage from './ReferralsPage.jsx';

// One menu entry ("Performance improvement", /improvement):
//   - committee, department head, dean and concerned-office members work with referrals,
//   - admin also manages the concerned offices and their members.
const REFERRAL_ROLES = ['admin', 'committee', 'department_head', 'dean', 'concerned_office'];
const TABS = [
  { key: 'referrals', label: 'Referrals' },
  { key: 'offices', label: 'Concerned offices' },
];

export default function ImprovementHubPage({ user }) {
  const [params] = useSearchParams();
  const [tab, setTab] = useState('referrals');
  const role = user?.role;

  if (!REFERRAL_ROLES.includes(role)) {
    return (
      <section className="panel-card">
        <EmptyBlock title="Performance improvement">
          Performance gaps from finalized evaluations are referred to the concerned offices, which plan support and
          capacity-building activities. Your role does not use this area.
        </EmptyBlock>
      </section>
    );
  }

  if (role !== 'admin' || params.get('open')) return <ReferralsPage user={user} />;

  return (
    <div className="space-y-6">
      <Tabs tabs={TABS} active={tab} onChange={setTab} label="Performance improvement" />
      <div role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`}>
        {tab === 'referrals' ? <ReferralsPage user={user} /> : <OfficesPage />}
      </div>
    </div>
  );
}